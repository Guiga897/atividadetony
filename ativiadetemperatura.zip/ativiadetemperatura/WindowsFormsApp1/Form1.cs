﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Temperatura : Form
    {
        private StringBuilder bufferRecebido = new StringBuilder();
        public Temperatura()
        {
            InitializeComponent();
            timer1.Interval = 2000;
            timer1.Start();
            serialPort1.DataReceived += SerialPort1_DataReceived;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    if (button2.Text == "Ligar")
                    {
                        // Envia comando para ligar LED principal e LED de status
                        serialPort1.Write("LED:1\n");
                        serialPort1.Write("STATUS:1\n");
                        button2.Text = "Desligar";
                        button2.BackColor = Color.LightGreen;
                    }
                    else
                    {
                        // Envia comando para desligar LED principal e LED de status
                        serialPort1.Write("LED:0\n");
                        serialPort1.Write("STATUS:0\n");
                        button2.Text = "Ligar";
                        button2.BackColor = SystemColors.Control;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao enviar o comando: " + ex.Message, "Erro",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Conecte-se à porta serial primeiro!", "Aviso",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                desconectarSerial();
            }
            else
            {
                conectarSerial();
            }
        }

        
        private void timer2_Tick(object sender, EventArgs e)
        {
            AtualizaCOMs();
        }

        private void AtualizaCOMs()
        {
            int i;
            bool quantDiferente;

            i = 0;
            quantDiferente = false;

            if (comboBox1.Items.Count == SerialPort.GetPortNames().Length)
            {
                foreach (string s in SerialPort.GetPortNames())
                {
                    if (comboBox1.Items[i++].Equals(s) == false)
                    {
                        quantDiferente = true;
                    }
                }
            }
            else
            {
                quantDiferente = true;
            }

            if (quantDiferente == false)
            {
                return;
            }

            comboBox1.Items.Clear();

            foreach (string s in SerialPort.GetPortNames())
            {
                comboBox1.Items.Add(s);
            }

            comboBox1.SelectedIndex = 0;

        }
        
        private void conectarSerial()
        {
            if (comboBox1.SelectedItem == null || comboBox1.SelectedItem.ToString() == "Nenhuma porta encontrada")
            {
                MessageBox.Show("Selecione uma porta COM válida!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                serialPort1.PortName = comboBox1.SelectedItem.ToString();
                serialPort1.BaudRate = 9600;
                serialPort1.Parity = Parity.None;
                serialPort1.DataBits = 8;
                serialPort1.StopBits = StopBits.One;
                serialPort1.Handshake = Handshake.None;
                
                serialPort1.Open();
                button1.Text = "Desconectar";
                comboBox1.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao conectar: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void desconectarSerial() {
            try
            {
                serialPort1.Close();
                comboBox1.Enabled = true;
                button1.Text = "Conectar";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao desconectar: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (serialPort1.IsOpen)
                serialPort1.Close();
        }
        private StringBuilder serialBuffer = new StringBuilder();

        private void SerialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string rawData = serialPort1.ReadExisting();
                serialBuffer.Append(rawData);

                ProcessBuffer();
            }
            catch (Exception ex)
            {
                this.Invoke(new Action(() => {
                    UpdateLabelSafe(label1, "Tensão: Erro");
                    UpdateLabelSafe(label2, "Temperatura: Erro");
                    Debug.WriteLine($"Erro na leitura serial: {ex.Message}");
                }));
            }
        }

        private void ProcessBuffer()
        {
            string bufferContent = serialBuffer.ToString();

            // Processa cada linha completa recebida
            while (bufferContent.Contains("\n"))
            {
                int lineEnd = bufferContent.IndexOf("\n");
                string completeLine = bufferContent.Substring(0, lineEnd).Trim();
                bufferContent = bufferContent.Substring(lineEnd + 1);

                this.Invoke(new Action(() => ProcessDataLine(completeLine)));
            }

            serialBuffer = new StringBuilder(bufferContent);
        }

        private void ProcessDataLine(string dataLine)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(dataLine))
                    return;

                // Verifica e processa dados de temperatura
                if (dataLine.StartsWith("TEMP:"))
                {
                    ProcessTemperatureData(dataLine);
                    return;
                }

                // Verifica e processa dados de tensão
                if (dataLine.StartsWith("VOLT:"))
                {
                    ProcessVoltageData(dataLine);
                    return;
                }

                Debug.WriteLine($"Formato não reconhecido: {dataLine}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Erro ao processar linha: {dataLine}. Erro: {ex.Message}");
            }
        }

        private void ProcessTemperatureData(string tempData)
        {
            try
            {
                string tempValueStr = tempData.Substring(5).Trim(); // Remove "TEMP:"

                if (double.TryParse(tempValueStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double temperatura))
                {
                    // Validação do range de temperatura (ajuste conforme seu sensor)
                    if (temperatura >= -50 && temperatura <= 150)
                    {
                        UpdateLabelSafe(label2, $"Temperatura: {Math.Round(temperatura, 1)} °C");
                        return;
                    }
                }

                UpdateLabelSafe(label2, "Temperatura: Inválida");
            }
            catch (Exception ex)
            {
                UpdateLabelSafe(label2, "Temperatura: Erro");
                Debug.WriteLine($"Erro ao processar temperatura: {ex.Message}");
            }
        }

        private void ProcessVoltageData(string voltData)
        {
            try
            {
                string voltValueStr = voltData.Substring(5).Trim(); // Remove "VOLT:"

                if (double.TryParse(voltValueStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double porcentagem))
                {
                    // Validação do range de porcentagem (0-100%)
                    if (porcentagem >= 0 && porcentagem <= 100)
                    {
                        UpdateLabelSafe(label1, $"Tensão: {Math.Round(porcentagem, 1)} %");
                        return;
                    }
                }

                UpdateLabelSafe(label1, "Tensão: Inválida");
            }
            catch (Exception ex)
            {
                UpdateLabelSafe(label1, "Tensão: Erro");
                Debug.WriteLine($"Erro ao processar tensão: {ex.Message}");
            }
        }

        private void UpdateLabelSafe(Label label, string text)
        {
            try
            {
                if (label.InvokeRequired)
                {
                    label.Invoke(new Action(() => label.Text = text));
                }
                else
                {
                    label.Text = text;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Erro ao atualizar label: {ex.Message}");
            }
        }

        private void AtualizaCOMs(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string[] portas = SerialPort.GetPortNames();

            if (portas.Length == 0)
            {
                comboBox1.Items.Add("nenhuma porta encontrada");
                comboBox1.SelectedIndex = 0;
                return;
            }
            foreach (string porta in portas)
                comboBox1.Items.Add(porta);
            comboBox1.SelectedIndex = 0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            AtualizaCOMs();
        }
    }

}
